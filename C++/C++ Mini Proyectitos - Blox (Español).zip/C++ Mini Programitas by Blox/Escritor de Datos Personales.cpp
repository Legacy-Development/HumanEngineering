#include<iostream>

using namespace std;

int main(){
	int edad;
	char sexo[10];
	float altura;
	
	cout<<"Cual es su edad: "; cin>>edad;
	cout<<"Cual es su sexo: "; cin>>sexo;
	cout<<"Cuanto mide?: "; cin>>altura;
	
	cout<<"\nEdad: "<<edad<<endl;
	cout<<"\nSexo: "<<sexo<<endl;
	cout<<"\nAltura en metros y centimetros: "<<altura<<endl;
	
	return 0;
}
