#include<iostream>

using namespace std;

int main(){
	float Jose,Juan,Jorge,Julio, respuesta = 0;
	
	cout<<"Cual es la calificacion de Jose?: "; cin>>Jose;
	cout<<"Cual es la calificacion de Juan?: "; cin>>Juan;
	cout<<"Cual es la calificacion de Jorge?: "; cin>>Jorge;
	cout<<"Cual es la calificacion de Julio?: "; cin>>Julio;
	
	cout<<"\nLa calificacion de Jose es: "<<Jose<<endl;
	cout<<"\nLa calificacion de Juan es: "<<Juan<<endl;
	cout<<"\nLa calificacion de Jorge es: "<<Jorge<<endl;
	cout<<"\nLa calificacion de Julio es: "<<Julio<<endl;

	return 0;
}
