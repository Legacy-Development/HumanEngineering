#include<iostream>

using namespace std;

int main(){
	float b,a,c,d, resultado = 0;
	
	cout<<"digite el valor de B: "; cin>>b;
    cout<<"digite el valor de A: "; cin>>a;
	cout<<"digite el valor de C: "; cin>>c;
	cout<<"digite el valor de D: "; cin>>d;
	
	resultado = (b+ a+b/c+d);
	
	cout<<"\nEl resultado es: "<<resultado<<endl;

	return 0;
}
