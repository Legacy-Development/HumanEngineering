#include<iostream>

using namespace std;

int main(){
	float a,b, resultado = 0;
	
	cout<<"digite el valor de A: "; cin>>a;
    cout<<"digite el valor de B: "; cin>>b;
	
	resultado = (a/b + 1);
	
	cout.precision(4);
	cout<<"\nEl resultado es: "<<resultado<<endl;

	return 0;
}
