#include<iostream>

using namespace std;

int main(){
	int entero; //variable definida
	
	cout<<"digite un numero entero: "; 
	cin>>entero; //variable guardada
	
	cout<<"\El numero que digito es: "<<entero;
	
	
	return 0;
}
