#include<iostream>

using namespace std;

int main(){
	int numero = 10;
	float flotante = 10.2314;
	double doble = 19.4596;
	char letra = 'X';
	
	cout<<flotante;
	cout<<numero;
	cout<<doble;
	cout<<letra;
	
	
	return 0;
}
