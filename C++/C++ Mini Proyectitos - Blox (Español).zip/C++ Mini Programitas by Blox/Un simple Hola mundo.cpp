//C++ 

#include<iostream>

using namespace std;

int main(){
	
	cout<<"Hola a todos, Hola mundo en C++"<<endl;
	cout<<"En este peque�o proyectito vamos a aprender a programar en C++";
	
	return 0;
}
