#include<iostream>

using namespace std;

int main(){
	float Mexico,Chile,Argentina, respuesta = 0;
	
	cout<<"La calificacion de Mexico es: "; cin>>Mexico;
	cout<<"La calificacion de Chile es: "; cin>>Chile;
	cout<<"La calificacion de Argentina es: "; cin>>Argentina;
	
	cout<<"\nLa calificacion de Mexico es: "<<Mexico<<endl;
	cout<<"\nLa calificacion de Chile es: "<<Chile<<endl;
	cout<<"\nLa calificacion de Argentina es: "<<Argentina<<endl;

if(Mexico > Chile,Argentina)
cout<<"\nes acaso Mexico mejor que todos los paises?, Esta es su puntuacion: "<<Mexico<<endl;
else if(Chile,Argentina > Mexico)
cout<<"\nNada..."<<Mexico<<endl;

if(Chile > Chile,Argentina)
cout<<"\nes acaso Chile mejor que todos los paises?, Esta es su puntuacion: "<<Chile<<endl;
else if(Chile,Argentina > Mexico)
cout<<"\nNada..."<<Chile<<endl;

if(Argentina > Chile,Argentina)
cout<<"\nes acaso Argentina mejor que todos los paises?, Esta es su puntuacion: "<<Argentina<<endl;
else if(Chile,Argentina > Mexico)
cout<<"\nNada..."<<Argentina<<endl;

cout<<"\n � Gracias por compilarme. :3"<<endl;

	return 0;
}
